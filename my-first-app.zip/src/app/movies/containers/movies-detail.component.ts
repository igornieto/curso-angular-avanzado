import { Component } from "@angular/core";

@Component({
  selector: 'movies-detail-page',
  template: `
    <h1>Soy la página de detalle</h1>
  `
})
export class MoviesDetailPageComponent {

}