import { Component } from "@angular/core";

@Component({
  selector: 'comments-form',
  template: ``
})
export class CommentsForm {
  
}