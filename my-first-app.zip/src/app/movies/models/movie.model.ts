export interface Movie {
  title: string;
  overview: string;
  poster?: string;
  adult: boolean;
  vote: number;
} 