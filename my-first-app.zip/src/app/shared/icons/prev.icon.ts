import { Component } from "@angular/core";

@Component({
  selector: 'prev-icon',
  templateUrl: './prev.svg',
  styleUrls: ['./icons.scss']
})
export class PrevIcon {}