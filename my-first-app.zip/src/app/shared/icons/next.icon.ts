import { Component } from "@angular/core";

@Component({
  selector: 'next-icon',
  templateUrl: './next.svg',
  styleUrls: ['./icons.scss']
})
export class NextIcon {}