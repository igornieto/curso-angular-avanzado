import { Component } from "@angular/core";

@Component({
  selector: 'star-icon',
  templateUrl: './star.svg',
  styleUrls: ['./icons.scss']
})
export class StarIcon {}