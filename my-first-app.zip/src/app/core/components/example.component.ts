
import { Component, Input } from "@angular/core";

@Component({
  selector: 'example',
  template: `
    
  `
})
export class ExampleComponent {

  model = {
    name: 'Igor',
    age: 32,
  }

  handleSubmit() {
    debugger;
    //
  }

}

