export interface Profile {
  firstname: string;
  lastname: string;
  email: string;
  picture: string;
}