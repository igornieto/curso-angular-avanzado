import { Component } from "@angular/core";

@Component({
  selector: 'dashboard-page',
  template: `
    <h1>Soy el dashboard</h1>
  `
})
export class DashboardPageComponent {

}