import { Component } from "@angular/core";

@Component({
  selector: 'movies-page',
  template: `
    <h1>Soy la página de películas</h1>
  `
})
export class MoviesPageComponent {

}